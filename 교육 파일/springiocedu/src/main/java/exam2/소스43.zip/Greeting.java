package exam2;

public interface Greeting {
    public abstract void greet();
}
