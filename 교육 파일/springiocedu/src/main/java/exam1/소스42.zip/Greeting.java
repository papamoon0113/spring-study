package exam1;

public interface Greeting {
    public void greet();
}
